package org.example.App.modules;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import org.example.App.services.BookingService;
import org.example.App.services.PriceService;
import org.example.App.services.UserService;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class BookingModule {

    private final UserService userService;
    private final BookingService bookingService;
    private final PriceService priceService;

    public BookingModule(UserService userService, BookingService bookingService, PriceService priceService) {
        this.userService = userService;
        this.bookingService = bookingService;
        this.priceService = priceService;
    }

    public Node build() {
        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #0b1220;");

        Label title = new Label("訂票");
        title.getStyleClass().add("h2");

        ComboBox<String> movieBox = new ComboBox<>();
        for (BookingService.Movie m : bookingService.getMovies()) {
            movieBox.getItems().add(m.title);
        }
        movieBox.setValue("阿凡達：火與燼");

        ComboBox<String> cinemaBox = new ComboBox<>();
        cinemaBox.getItems().addAll("威秀", "國賓", "美麗華");
        cinemaBox.setValue("威秀");

        DatePicker datePicker = new DatePicker(LocalDate.now());
        datePicker.getEditor().getStyleClass().add("light-input"); // 白底黑字
        // 若你有 light-date class 也可以加上：
        datePicker.getStyleClass().add("light-date");

        ComboBox<String> timeBox = new ComboBox<>();
        timeBox.getItems().addAll("13:10", "15:40", "18:20", "20:50");
        timeBox.setValue("18:20");

        ComboBox<String> ticketTypeBox = new ComboBox<>();
        ticketTypeBox.getItems().addAll("全票", "學生票", "敬老票", "愛心票");
        ticketTypeBox.setValue("全票");

        CheckBox idVerification = new CheckBox("我已驗證身分証");
        idVerification.setStyle("-fx-text-fill: white;");

        ticketTypeBox.valueProperty().addListener((obs, o, n) -> {
            idVerification.setVisible("學生票".equals(n));
            if (!"學生票".equals(n)) idVerification.setSelected(false);
        });
        idVerification.setVisible(false);

        Spinner<Integer> qtySpinner = new Spinner<>(1, 10, 1);
        qtySpinner.getEditor().getStyleClass().add("light-input"); // 白底黑字

        ComboBox<String> discountBox = new ComboBox<>();
        discountBox.getItems().add("無");
        for (PriceService.Discount d : priceService.getAvailableDiscounts()) {
            discountBox.getItems().add(d.code + " - " + d.name + " (" + d.percentage + "% 折扣)");
        }
        discountBox.setValue("無");

        CheckBox mealCheckBox = new CheckBox("加購配餐");
        mealCheckBox.setStyle("-fx-text-fill: white;");

        HBox mealBox = new HBox(10);
        mealBox.setPadding(new Insets(10));
        mealBox.setStyle("-fx-border-color: rgba(255,255,255,0.1); -fx-border-radius: 8;");

        ComboBox<String> mealTypeBox = new ComboBox<>();
        mealTypeBox.getItems().addAll(
                "爆米花+飲料 (NT$150)",
                "熱狗+飲料 (NT$180)",
                "漢堡+薯條 (NT$200)"
        );
        mealTypeBox.setDisable(true);

        Spinner<Integer> mealQtySpinner = new Spinner<>(0, 5, 0);
        mealQtySpinner.getEditor().getStyleClass().add("light-input"); // 白底黑字
        mealQtySpinner.setDisable(true);

        mealCheckBox.selectedProperty().addListener((obs, o, n) -> {
            mealTypeBox.setDisable(!n);
            mealQtySpinner.setDisable(!n);
        });

        Label mealTypeLabel = new Label("配餐類型:");
        mealTypeLabel.setStyle("-fx-text-fill: white;");
        Label mealQtyLabel = new Label("數量:");
        mealQtyLabel.setStyle("-fx-text-fill: white;");

        mealBox.getChildren().addAll(mealTypeLabel, mealTypeBox, mealQtyLabel, mealQtySpinner);

        Button nextBtn = new Button("下一步 - 選擇座位");
        nextBtn.getStyleClass().add("primary");
        nextBtn.setStyle("-fx-padding: 12 30;");
        nextBtn.setOnAction(e -> {
            if (!userService.isLoggedIn()) {
                showAlert("請先登入");
                return;
            }
            if (idVerification.isVisible() && !idVerification.isSelected()) {
                showAlert("請驗證身分證");
                return;
            }
            showSeatSelection(
                    movieBox.getValue(),
                    cinemaBox.getValue(),
                    datePicker.getValue(),
                    timeBox.getValue(),
                    ticketTypeBox.getValue(),
                    qtySpinner.getValue(),
                    discountBox.getValue(),
                    mealCheckBox.isSelected() ? mealTypeBox.getValue() : null
            );
        });

        VBox form = new VBox(12);
        form.setPadding(new Insets(15));
        form.setStyle("-fx-border-color: rgba(255,255,255,0.08); -fx-border-radius: 12; -fx-background-color: rgba(255,255,255,0.02);");

        Label l1 = new Label("電影"); l1.setStyle("-fx-text-fill: white;");
        Label l2 = new Label("影城"); l2.setStyle("-fx-text-fill: white;");
        Label l3 = new Label("日期"); l3.setStyle("-fx-text-fill: white;");
        Label l4 = new Label("時間"); l4.setStyle("-fx-text-fill: white;");
        Label l5 = new Label("票種"); l5.setStyle("-fx-text-fill: white;");
        Label l6 = new Label("張數"); l6.setStyle("-fx-text-fill: white;");
        Label l7 = new Label("優惠碼"); l7.setStyle("-fx-text-fill: white;");

        form.getChildren().addAll(
                l1, movieBox,
                l2, cinemaBox,
                l3, datePicker,
                l4, timeBox,
                l5, ticketTypeBox,
                idVerification,
                l6, qtySpinner,
                l7, discountBox,
                mealCheckBox,
                mealBox,
                nextBtn
        );

        root.getChildren().addAll(title, form);

        ScrollPane sp = new ScrollPane(root);
        sp.setFitToWidth(true);
        sp.setStyle("-fx-background: transparent; -fx-background-color: transparent;");
        return sp;
    }

    private void showSeatSelection(String movie, String cinema, LocalDate date, String time,
                                   String ticketType, int qty, String discount, String meal) {

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("選擇座位");
        dialog.getDialogPane().setPrefWidth(900);
        dialog.getDialogPane().setPrefHeight(700);

        GridPane seatGrid = new GridPane();
        seatGrid.setHgap(8);
        seatGrid.setVgap(8);
        seatGrid.setPadding(new Insets(20));
        seatGrid.setStyle("-fx-background-color: #0b1220;");

        List<ToggleButton> selectedSeats = new ArrayList<>();

        for (int row = 0; row < 8; row++) {
            for (int col = 0; col < 12; col++) {
                ToggleButton seat = new ToggleButton((char) ('A' + row) + String.valueOf(col + 1));
                seat.getStyleClass().add("seat");
                seat.setPrefWidth(55);
                seat.setPrefHeight(55);
                seat.setStyle("-fx-font-weight: bold; -fx-text-fill: white;");

                final ToggleButton finalSeat = seat;
                seat.selectedProperty().addListener((obs, o, n) -> {
                    if (n) {
                        if (selectedSeats.size() < qty) {
                            selectedSeats.add(finalSeat);
                        } else {
                            finalSeat.setSelected(false);
                            showAlert("最多選 " + qty + " 個座位");
                        }
                    } else {
                        selectedSeats.remove(finalSeat);
                    }
                });

                seatGrid.add(seat, col, row);
            }
        }

        ScrollPane scrollSeats = new ScrollPane(seatGrid);
        scrollSeats.setFitToWidth(true);
        scrollSeats.setStyle("-fx-background-color: #0b1220; -fx-background: #0b1220;");

        Button autoBtn = new Button("自動選位");
        autoBtn.getStyleClass().add("ghost");
        autoBtn.setOnAction(e -> {
            selectedSeats.forEach(s -> s.setSelected(false));
            selectedSeats.clear();

            Random rand = new Random();
            Set<String> used = new HashSet<>();

            for (int i = 0; i < qty; i++) {
                String seatId;
                do {
                    int r = rand.nextInt(8);
                    int c = rand.nextInt(12);
                    seatId = (char) ('A' + r) + String.valueOf(c + 1);
                } while (used.contains(seatId));
                used.add(seatId);

                for (javafx.scene.Node node : seatGrid.getChildren()) {
                    if (node instanceof ToggleButton btn && btn.getText().equals(seatId)) {
                        btn.setSelected(true);
                        break;
                    }
                }
            }
        });

        VBox seatContainer = new VBox(10, autoBtn, scrollSeats);
        VBox.setVgrow(scrollSeats, Priority.ALWAYS);
        seatContainer.setStyle("-fx-background-color: #0b1220;");

        dialog.getDialogPane().setContent(seatContainer);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dialog.getDialogPane().setStyle("-fx-background-color: #0b1220;");

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                if (selectedSeats.isEmpty()) {
                    showAlert("請選擇座位");
                } else {
                    List<String> seatList = new ArrayList<>();
                    for (ToggleButton s : selectedSeats) seatList.add(s.getText());
                    showPayment(movie, cinema, date.toString(), time, ticketType, qty, seatList, discount, meal);
                }
            }
            return btn;
        });

        dialog.showAndWait();
    }

    private void showPayment(String movie, String cinema, String date, String time,
                             String ticketType, int qty, List<String> seats, String discount, String meal) {

        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("確認訂單 & 付款");
        dialog.getDialogPane().setPrefWidth(600);

        int basePrice = 300;
        int mealPrice = 0;

        if (meal != null) {
            if (meal.contains("150")) mealPrice = 150;
            else if (meal.contains("180")) mealPrice = 180;
            else mealPrice = 200;
        }

        int totalPrice = qty * basePrice + (meal != null ? mealPrice : 0);

        // ✅ 修正：正確處理折扣碼（避免 String[] -> String）
        if (discount != null && !discount.equals("無")) {
            // discount 格式：CODE - NAME (xx% 折扣)
            String discountCode = discount.split("\\s*-\\s*")[0].trim(); // 取第一段 CODE
            totalPrice = priceService.applyDiscount(totalPrice, discountCode);
        }

        Label summary = new Label(
                "片名: " + movie + "\n" +
                        "影城: " + cinema + "\n" +
                        "日期: " + date + "\n" +
                        "時間: " + time + "\n" +
                        "票種: " + ticketType + "\n" +
                        "座位: " + String.join(", ", seats) + "\n" +
                        "張數: " + qty + "\n" +
                        "配餐: " + (meal != null ? meal : "無") + "\n" +
                        "折扣: " + discount + "\n" +
                        "總金額: NT$ " + totalPrice
        );
        summary.setStyle("-fx-text-fill: rgba(255,255,255,0.9); -fx-wrap-text: true;");
        summary.setWrapText(true);

        ToggleGroup paymentGroup = new ToggleGroup();
        RadioButton creditCard = new RadioButton("信用卡");
        creditCard.setToggleGroup(paymentGroup);
        creditCard.setSelected(true);
        creditCard.setStyle("-fx-text-fill: white;");

        RadioButton linePay = new RadioButton("LINE Pay");
        linePay.setToggleGroup(paymentGroup);
        linePay.setStyle("-fx-text-fill: white;");

        VBox paymentBox = new VBox(8, creditCard, linePay);

        TextField cardNumber = new TextField();
        cardNumber.setPromptText("卡號");
        cardNumber.getStyleClass().add("light-input");

        TextField cardHolder = new TextField();
        cardHolder.setPromptText("持卡人");
        cardHolder.getStyleClass().add("light-input");

        TextField expiry = new TextField();
        expiry.setPromptText("MM/YY");
        expiry.getStyleClass().add("light-input");

        PasswordField cvv = new PasswordField();
        cvv.setPromptText("CVV");
        cvv.getStyleClass().add("light-input");

        VBox cardBox = new VBox(8, cardNumber, cardHolder, expiry, cvv);

        creditCard.selectedProperty().addListener((obs, o, n) -> cardBox.setVisible(n));
        cardBox.setVisible(true);

        Label payTitle = new Label("付款方式");
        payTitle.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");
        Label cardTitle = new Label("卡片資料");
        cardTitle.setStyle("-fx-text-fill: white; -fx-font-weight: bold;");

        VBox root = new VBox(15, summary, new Separator(), payTitle, paymentBox, cardTitle, cardBox);
        root.setPadding(new Insets(15));
        root.setStyle("-fx-background-color: #0b1220;");

        ScrollPane scroll = new ScrollPane(root);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: #0b1220; -fx-background: #0b1220;");

        dialog.getDialogPane().setContent(scroll);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dialog.getDialogPane().setStyle("-fx-background-color: #0b1220;");

        int finalTotalPrice = totalPrice;
        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                RadioButton selectedBtn = (RadioButton) paymentGroup.getSelectedToggle();
                if (selectedBtn != null) {
                    String paymentMethod = selectedBtn.getText();

                    if ("信用卡".equals(paymentMethod)) {
                        String cardNum = cardNumber.getText();
                        String holder = cardHolder.getText();
                        String exp = expiry.getText();
                        String cvvNum = cvv.getText();

                        if (cardNum.length() != 16 || !cardNum.matches("\\d+")) {
                            showAlert("卡號必須為 16 位數字");
                            return btn;
                        }
                        if (holder.isBlank() || exp.isBlank() || cvvNum.isBlank()) {
                            showAlert("請填寫完整卡片資訊");
                            return btn;
                        }
                    }

                    BookingService.Booking booking = bookingService.createBooking(
                            userService.getCurrentUserId(), movie, cinema,
                            LocalDate.parse(date), LocalTime.parse(time), seats, finalTotalPrice
                    );
                    bookingService.confirmPayment(booking);
                    bookingService.updateRemaining(movie, qty);

                    showAlert("付款成功！\n\n電子票卷碼: " + booking.ticketCode + "\n訂單 ID: " + booking.bookingId);
                }
            }
            return btn;
        });

        dialog.showAndWait();
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg);
        alert.getDialogPane().setStyle("-fx-background-color: #0b1220;");
        alert.showAndWait();
    }
}
