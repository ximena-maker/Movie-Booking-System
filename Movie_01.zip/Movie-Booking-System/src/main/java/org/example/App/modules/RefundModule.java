package org.example.App.modules;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import org.example.App.services.BookingService;
import org.example.App.services.UserService;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class RefundModule {
    private BookingService bookingService;
    private UserService userService;

    public RefundModule(BookingService bookingService, UserService userService) {
        this.bookingService = bookingService;
        this.userService = userService;
    }

    public Node build() {
        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #0b1220;");

        Label title = new Label("↩️ 退票");
        title.setStyle("-fx-font-size: 28; -fx-text-fill: #32b8c6; -fx-font-weight: bold;");

        TextField bookingIdField = new TextField();
        bookingIdField.setPromptText("輸入訂單 ID (例: BK1704107668000)");
        bookingIdField.setStyle("-fx-padding: 8; -fx-font-size: 12;");

        Button searchBtn = new Button("🔍 查詢訂單");
        searchBtn.setStyle("-fx-padding: 8 20; -fx-font-size: 12; -fx-background-color: #32b8c6; " +
                "-fx-text-fill: white; -fx-border-radius: 5;");

        HBox searchBox = new HBox(10, bookingIdField, searchBtn);
        searchBox.setStyle("-fx-padding: 10; -fx-border-color: rgba(50,184,198,0.2); -fx-border-radius: 8; " +
                "-fx-background-color: rgba(26,38,55,0.5);");

        TextArea resultArea = new TextArea();
        resultArea.setEditable(false);
        resultArea.setWrapText(true);
        resultArea.setStyle("-fx-control-inner-background: #1a2637; -fx-text-fill: rgba(255,255,255,0.9); " +
                "-fx-padding: 10; -fx-font-family: monospace; -fx-font-size: 11;");
        resultArea.setPrefHeight(250);

        Button refundBtn = new Button("✓ 確認退票");
        refundBtn.setStyle("-fx-padding: 10 30; -fx-font-size: 12; -fx-background-color: #c63530; " +
                "-fx-text-fill: white; -fx-border-radius: 5;");
        refundBtn.setDisable(true);

        searchBtn.setOnAction(e -> {
            String bookingId = bookingIdField.getText().trim();
            if (bookingId.isBlank()) {
                showAlert("❌ 請輸入訂單 ID");
                return;
            }

            // ✅ 修正：使用正確的字段名稱
            for (BookingService.Booking b : bookingService.getAllBookings()) {
                if (b.bookingId.equals(bookingId)) {
                    // 檢查是否是當前用戶的訂單
                    if (!userService.isLoggedIn() || !b.userId.equals(userService.getCurrentUserId())) {
                        showAlert("❌ 您沒有權限查詢此訂單");
                        return;
                    }

                    // 計算退款比例
                    LocalDate showDate = b.bookingDate;
                    LocalDate today = LocalDate.now();
                    long daysUntilShow = ChronoUnit.DAYS.between(today, showDate);

                    double refundRate = 0.0;
                    String refundInfo = "";

                    if (daysUntilShow >= 7) {
                        refundRate = 1.0;
                        refundInfo = "✓ 演出前 7 天：全額退款 100%";
                    } else if (daysUntilShow >= 3) {
                        refundRate = 0.8;
                        refundInfo = "✓ 演出前 3-6 天：退款 80%";
                    } else if (daysUntilShow >= 1) {
                        refundRate = 0.5;
                        refundInfo = "✓ 演出前 1-2 天：退款 50%";
                    } else {
                        refundRate = 0.0;
                        refundInfo = "✗ 演出當日或已過期：不可退票";
                    }

                    int refundAmount = (int) (b.totalPrice * refundRate);

                    resultArea.setText(
                            "╔════════════════════════════════════════╗\n" +
                                    "║         退票訂單信息                    ║\n" +
                                    "╚════════════════════════════════════════╝\n\n" +
                                    "📋 訂單基本信息\n" +
                                    "─────────────────────────────────────────\n" +
                                    "  訂單 ID: " + b.bookingId + "\n" +
                                    "  狀態: " + b.status + "\n" +
                                    "  電子票卷: " + (b.ticketCode != null ? b.ticketCode : "未發放") + "\n\n" +

                                    "🎬 電影信息\n" +
                                    "─────────────────────────────────────────\n" +
                                    "  片名: " + b.movieTitle + "\n" +
                                    "  影城: " + b.cinema + "\n" +
                                    "  日期: " + b.bookingDate + "\n" +
                                    "  時間: " + b.bookingTime + "\n" +
                                    "  座位: " + String.join(", ", b.seats) + "\n\n" +

                                    "💰 退款信息\n" +
                                    "─────────────────────────────────────────\n" +
                                    "  原購票金額: NT$ " + b.totalPrice + "\n" +
                                    "  退款金額: NT$ " + refundAmount + "\n" +
                                    "  退款比例: " + (int)(refundRate * 100) + "%\n\n" +

                                    "📅 退款規則\n" +
                                    "─────────────────────────────────────────\n" +
                                    "  演出日期: " + b.bookingDate + " 距今: " + daysUntilShow + " 天\n" +
                                    "  " + refundInfo + "\n\n" +

                                    "ℹ️ 退票說明\n" +
                                    "─────────────────────────────────────────\n" +
                                    "  ✓ 退款將於 3-5 個工作天內退至原付款帳戶\n" +
                                    "  ✓ 手續費為退款金額的 10%\n" +
                                    "  ✓ 退票後無法再用該電子票卷進場"
                    );

                    // ✅ 修正：將變量設為 final，以便在 Lambda 中使用（第 135 和 140 行的問題）
                    final double finalRefundRate = refundRate;
                    final BookingService.Booking finalBooking = b;

                    refundBtn.setDisable(finalRefundRate == 0.0);

                    refundBtn.setOnAction(f -> {
                        if (finalRefundRate == 0.0) {
                            showAlert("❌ 該訂單已無法退票");
                            return;
                        }

                        int finalRefundAmount = (int) (finalBooking.totalPrice * finalRefundRate);

                        // 確認對話框
                        Dialog<ButtonType> confirmDialog = new Dialog<>();
                        confirmDialog.setTitle("確認退票");
                        Label confirmMsg = new Label(
                                "確定要退票嗎？\n\n" +
                                        "原購票金額: NT$ " + finalBooking.totalPrice + "\n" +
                                        "退款金額: NT$ " + finalRefundAmount + "\n" +
                                        "手續費: NT$ " + (finalRefundAmount / 10) + "\n" +
                                        "實退金額: NT$ " + (finalRefundAmount - finalRefundAmount / 10)
                        );
                        confirmMsg.setStyle("-fx-text-fill: white; -fx-font-size: 13;");

                        VBox confirmBox = new VBox(confirmMsg);
                        confirmBox.setPadding(new Insets(15));
                        confirmBox.setStyle("-fx-background-color: #0b1220;");

                        confirmDialog.getDialogPane().setContent(confirmBox);
                        confirmDialog.getDialogPane().getButtonTypes().addAll(ButtonType.YES, ButtonType.NO);
                        confirmDialog.getDialogPane().setStyle("-fx-background-color: #0b1220;");

                        if (confirmDialog.showAndWait().orElse(ButtonType.NO) == ButtonType.YES) {
                            bookingService.refundBooking(finalBooking.bookingId);
                            showAlert("✅ 退票成功！\n\n" +
                                    "原購票金額: NT$ " + finalBooking.totalPrice + "\n" +
                                    "退款金額: NT$ " + finalRefundAmount + "\n" +
                                    "手續費: NT$ " + (finalRefundAmount / 10) + "\n" +
                                    "實退金額: NT$ " + (finalRefundAmount - finalRefundAmount / 10) + "\n\n" +
                                    "退款將於 3-5 個工作天內退至您的原付款帳戶");
                            resultArea.clear();
                            refundBtn.setDisable(true);
                            bookingIdField.clear();
                        }
                    });
                    return;
                }
            }

            showAlert("❌ 找不到該訂單");
            refundBtn.setDisable(true);
        });

        VBox form = new VBox(12);
        form.setPadding(new Insets(15));
        form.setStyle("-fx-border-color: rgba(50,184,198,0.2); -fx-border-radius: 12; " +
                "-fx-background-color: rgba(26,38,55,0.5);");
        form.getChildren().addAll(
                searchBox,
                new Label("訂單詳情:"),
                resultArea,
                refundBtn
        );

        root.getChildren().addAll(title, form);
        VBox.setVgrow(form, Priority.ALWAYS);

        return new ScrollPane(root);
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg);
        alert.setTitle("提示");
        alert.getDialogPane().setStyle("-fx-background-color: #0b1220;");
        alert.showAndWait();
    }
}
