package org.example.App.services;

import java.util.*;

public class PriceService {

    public static class PriceQuote {
        public String cinema;
        public String format;
        public String ticketType;
        public int price;
        public String source;

        public PriceQuote(String cinema, String format, String ticketType, int price, String source) {
            this.cinema = cinema;
            this.format = format;
            this.ticketType = ticketType;
            this.price = price;
            this.source = source;
        }
    }

    private Map<String, Map<String, Integer>> priceMap = new HashMap<>();

    public PriceService() {
        initPrices();
    }

    private void initPrices() {
        Map<String, Integer> vieshow = new HashMap<>();
        vieshow.put("2D-ADULT", 320);
        vieshow.put("2D-STUDENT", 280);
        vieshow.put("2D-SENIOR", 250);
        vieshow.put("3D-ADULT", 350);
        vieshow.put("IMAX-ADULT", 380);
        priceMap.put("威秀", vieshow);

        Map<String, Integer> ambassador = new HashMap<>();
        ambassador.put("2D-ADULT", 340);
        ambassador.put("2D-STUDENT", 300);
        ambassador.put("2D-SENIOR", 270);
        ambassador.put("3D-ADULT", 360);
        ambassador.put("IMAX-ADULT", 390);
        priceMap.put("國賓", ambassador);

        Map<String, Integer> miramar = new HashMap<>();
        miramar.put("2D-ADULT", 330);
        miramar.put("2D-STUDENT", 290);
        miramar.put("2D-SENIOR", 260);
        miramar.put("3D-ADULT", 355);
        miramar.put("IMAX-ADULT", 385);
        priceMap.put("美麗華", miramar);
    }

    public List<PriceQuote> compare(String format, String ticketType) {
        List<PriceQuote> quotes = new ArrayList<>();
        String key = format + "-" + ticketType;

        for (String cinema : priceMap.keySet()) {
            Map<String, Integer> prices = priceMap.get(cinema);
            if (prices.containsKey(key)) {
                int price = prices.get(key);
                quotes.add(new PriceQuote(cinema, format, ticketType, price, cinema + " 官方"));
            }
        }

        quotes.sort(Comparator.comparingInt(q -> q.price));
        return quotes;
    }

    public int getLowestPrice(String format, String ticketType) {
        List<PriceQuote> quotes = compare(format, ticketType);
        if (quotes.isEmpty()) return -1;
        return quotes.get(0).price;
    }

    public static class Discount {
        public String code;
        public String name;
        public int percentage;
        public String type;

        public Discount(String code, String name, int percentage, String type) {
            this.code = code;
            this.name = name;
            this.percentage = percentage;
            this.type = type;
        }
    }

    private List<Discount> discounts = new ArrayList<>();

    public PriceService(boolean init) {
        if (init) initDiscounts();
    }

    private void initDiscounts() {
        discounts.add(new Discount("EARLY20", "早鳥票（7天前購票）", 20, "EARLY_BIRD"));
        discounts.add(new Discount("STUDENT15", "學生票", 15, "STUDENT"));
        discounts.add(new Discount("GROUP10", "團體票（10人以上）", 10, "GROUP"));
        discounts.add(new Discount("MEMBER5", "會員折扣", 5, "MEMBER"));
    }

    public int applyDiscount(int price, String discountCode) {
        initDiscounts();
        for (Discount d : discounts) {
            if (d.code.equals(discountCode)) {
                return (int)(price * (1 - d.percentage / 100.0));
            }
        }
        return price;
    }

    public List<Discount> getAvailableDiscounts() {
        initDiscounts();
        return discounts;
    }
}
