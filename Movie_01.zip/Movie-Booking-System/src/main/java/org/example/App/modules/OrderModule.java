package org.example.App.modules;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import org.example.App.services.BookingService;
import org.example.App.services.UserService;

import java.util.ArrayList;
import java.util.List;

public class OrderModule {
    private BookingService bookingService;
    private UserService userService;

    public OrderModule(BookingService bookingService, UserService userService) {
        this.bookingService = bookingService;
        this.userService = userService;
    }

    public static class OrderDisplay {
        public String bookingId;
        public String movieTitle;
        public String cinema;
        public String date;
        public String time;
        public String seats;
        public int totalPrice;
        public String status;
        public String ticketCode;

        public OrderDisplay(BookingService.Booking b) {
            this.bookingId = b.bookingId;
            this.movieTitle = b.movieTitle;
            this.cinema = b.cinema;
            // ✅ 修正：使用 bookingDate 和 bookingTime
            this.date = b.bookingDate.toString();
            this.time = b.bookingTime.toString();
            // ✅ 修正：seats 是 List<String>，轉換為逗號分隔的字符串
            this.seats = String.join(", ", b.seats);
            this.totalPrice = b.totalPrice;
            this.status = b.status;
            this.ticketCode = b.ticketCode != null ? b.ticketCode : "未發放";
        }

        public String getBookingId() { return bookingId; }
        public String getMovieTitle() { return movieTitle; }
        public String getCinema() { return cinema; }
        public String getDate() { return date; }
        public String getTime() { return time; }
        public String getSeats() { return seats; }
        public int getTotalPrice() { return totalPrice; }
        public String getStatus() { return status; }
        public String getTicketCode() { return ticketCode; }
    }

    public Node build() {
        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #0b1220;");

        Label title = new Label("📋 我的訂單");
        title.setStyle("-fx-font-size: 28; -fx-text-fill: #32b8c6; -fx-font-weight: bold;");

        TableView<OrderDisplay> table = new TableView<>();
        table.setStyle("-fx-background-color: #1a2637; -fx-text-fill: white;");
        table.setPrefHeight(400);

        TableColumn<OrderDisplay, String> bookingCol = new TableColumn<>("訂單 ID");
        bookingCol.setCellValueFactory(new PropertyValueFactory<>("bookingId"));
        bookingCol.setPrefWidth(120);

        TableColumn<OrderDisplay, String> movieCol = new TableColumn<>("電影");
        movieCol.setCellValueFactory(new PropertyValueFactory<>("movieTitle"));
        movieCol.setPrefWidth(150);

        TableColumn<OrderDisplay, String> cinemaCol = new TableColumn<>("影城");
        cinemaCol.setCellValueFactory(new PropertyValueFactory<>("cinema"));
        cinemaCol.setPrefWidth(100);

        TableColumn<OrderDisplay, String> dateCol = new TableColumn<>("日期");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));
        dateCol.setPrefWidth(120);

        TableColumn<OrderDisplay, String> timeCol = new TableColumn<>("時間");
        timeCol.setCellValueFactory(new PropertyValueFactory<>("time"));
        timeCol.setPrefWidth(80);

        TableColumn<OrderDisplay, String> seatsCol = new TableColumn<>("座位");
        seatsCol.setCellValueFactory(new PropertyValueFactory<>("seats"));
        seatsCol.setPrefWidth(120);

        TableColumn<OrderDisplay, Integer> priceCol = new TableColumn<>("金額");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("totalPrice"));
        priceCol.setPrefWidth(100);
        priceCol.setCellFactory(col -> new TableCell<OrderDisplay, Integer>() {
            @Override
            protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText("—");
                } else {
                    setText("NT$ " + item);
                }
            }
        });

        TableColumn<OrderDisplay, String> statusCol = new TableColumn<>("狀態");
        statusCol.setCellValueFactory(new PropertyValueFactory<>("status"));
        statusCol.setPrefWidth(100);
        statusCol.setCellFactory(col -> new TableCell<OrderDisplay, String>() {
            @Override
            protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText("—");
                } else {
                    setText(item);
                    if ("已付款".equals(item)) {
                        setStyle("-fx-text-fill: #32b8c6;");
                    } else if ("已退票".equals(item)) {
                        setStyle("-fx-text-fill: #c63530;");
                    } else {
                        setStyle("-fx-text-fill: #ff8c00;");
                    }
                }
            }
        });

        TableColumn<OrderDisplay, String> ticketCol = new TableColumn<>("電子票卷");
        ticketCol.setCellValueFactory(new PropertyValueFactory<>("ticketCode"));
        ticketCol.setPrefWidth(120);

        table.getColumns().addAll(bookingCol, movieCol, cinemaCol, dateCol, timeCol, seatsCol, priceCol, statusCol, ticketCol);

        Button refreshBtn = new Button("🔄 重新整理");
        refreshBtn.setStyle("-fx-padding: 8 20; -fx-font-size: 12; -fx-background-color: #32b8c6; " +
                "-fx-text-fill: white; -fx-border-radius: 5;");
        refreshBtn.setOnAction(e -> loadOrders(table));

        Label statsLabel = new Label("📊 統計: 加載中...");
        statsLabel.setStyle("-fx-text-fill: rgba(255,255,255,0.8); -fx-font-size: 13;");

        VBox statsBox = new VBox(10, statsLabel, table);
        VBox.setVgrow(table, Priority.ALWAYS);
        statsBox.setStyle("-fx-background-color: #0b1220;");

        root.getChildren().addAll(title, refreshBtn, statsBox);

        loadOrders(table);
        updateStats(table, statsLabel);

        table.setOnMouseClicked(e -> {
            if (e.getClickCount() == 2) {
                OrderDisplay selected = table.getSelectionModel().getSelectedItem();
                if (selected != null) {
                    showOrderDetails(selected);
                }
            }
        });

        return root;
    }

    private void loadOrders(TableView<OrderDisplay> table) {
        if (!userService.isLoggedIn()) {
            showAlert("❌ 請先登入");
            return;
        }

        String userId = userService.getCurrentUserId();
        List<BookingService.Booking> bookings = bookingService.getUserBookings(userId);
        List<OrderDisplay> displayList = new ArrayList<>();

        for (BookingService.Booking b : bookings) {
            displayList.add(new OrderDisplay(b));
        }

        table.getItems().setAll(displayList);
    }

    private void updateStats(TableView<OrderDisplay> table, Label statsLabel) {
        List<OrderDisplay> orders = table.getItems();
        int total = orders.size();
        int confirmed = (int) orders.stream().filter(o -> "已確認".equals(o.status)).count();
        int paid = (int) orders.stream().filter(o -> "已付款".equals(o.status)).count();
        int refunded = (int) orders.stream().filter(o -> "已退票".equals(o.status)).count();

        statsLabel.setText(String.format("📊 統計: 總計 %d 筆 | 已確認 %d 筆 | 已付款 %d 筆 | 已退票 %d 筆",
                total, confirmed, paid, refunded));
    }

    private void showOrderDetails(OrderDisplay order) {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("訂單詳情 - " + order.bookingId);
        dialog.setWidth(500);

        TextArea details = new TextArea();
        details.setEditable(false);
        details.setWrapText(true);
        details.setPrefHeight(400);
        details.setStyle("-fx-control-inner-background: #1a2637; -fx-text-fill: rgba(255,255,255,0.9); " +
                "-fx-font-family: monospace; -fx-font-size: 12;");

        details.setText(
                "╔════════════════════════════════════════╗\n" +
                        "║         訂單詳細信息                    ║\n" +
                        "╚════════════════════════════════════════╝\n\n" +
                        "📋 訂單基本信息\n" +
                        "─────────────────────────────────────────\n" +
                        "  訂單 ID: " + order.bookingId + "\n" +
                        "  電子票卷: " + order.ticketCode + "\n" +
                        "  狀態: " + order.status + "\n\n" +

                        "🎬 電影信息\n" +
                        "─────────────────────────────────────────\n" +
                        "  片名: " + order.movieTitle + "\n" +
                        "  影城: " + order.cinema + "\n" +
                        "  日期: " + order.date + "\n" +
                        "  時間: " + order.time + "\n" +
                        "  座位: " + order.seats + "\n\n" +

                        "💰 費用信息\n" +
                        "─────────────────────────────────────────\n" +
                        "  總金額: NT$ " + order.totalPrice + "\n\n" +

                        "ℹ️ 溫馨提醒\n" +
                        "─────────────────────────────────────────\n" +
                        "  ✓ 請在演出前 15 分鐘抵達影城\n" +
                        "  ✓ 電子票卷可在驗票機上掃碼兌換\n" +
                        "  ✓ 如有任何問題，請聯繫客服\n" +
                        "  ✓ 退票請在演出前 24 小時申請"
        );

        dialog.getDialogPane().setContent(details);
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        dialog.getDialogPane().setStyle("-fx-background-color: #0b1220;");

        dialog.showAndWait();
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg);
        alert.setTitle("提示");
        alert.getDialogPane().setStyle("-fx-background-color: #0b1220;");
        alert.showAndWait();
    }
}
