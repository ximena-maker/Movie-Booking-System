package org.example.App.services;

import java.util.HashMap;
import java.util.Map;

public class UserService {
    private Map<String, UserAccount> users = new HashMap<>();
    private String currentUserId;
    private boolean isCurrentUserAdmin = false;

    public static class UserAccount {
        public String userId;
        public String password;
        public boolean isAdmin;
        public String email;
        public String phone;

        public UserAccount(String userId, String password, boolean isAdmin) {
            this.userId = userId;
            this.password = password;
            this.isAdmin = isAdmin;
            this.email = userId + "@cinehub.com";
            this.phone = "0900000000";
        }
    }

    // 用戶認證
    public boolean authenticate(String userId, String password) {
        UserAccount account = users.get(userId);
        if (account != null && account.password.equals(password)) {
            currentUserId = userId;
            isCurrentUserAdmin = account.isAdmin;
            return true;
        }
        return false;
    }

    // ✅ LoginModule 需要的方法：用戶登入
    public boolean login(String userId, String password) {
        return authenticate(userId, password);
    }

    // ✅ LoginModule 需要的方法：用戶註冊
    public boolean register(String userId, String email, String password) {
        if (users.containsKey(userId)) {
            return false;
        }
        UserAccount account = new UserAccount(userId, password, false);
        account.email = email;
        users.put(userId, account);
        currentUserId = userId;
        isCurrentUserAdmin = false;
        return true;
    }

    // ✅ LoginModule 需要的方法：重置密碼
    public boolean resetPassword(String email) {
        for (UserAccount account : users.values()) {
            if (account.email.equals(email)) {
                // 實際應用中應該發送郵件，這裡模擬重設為預設密碼
                account.password = "1234";
                return true;
            }
        }
        return false;
    }

    // 用戶註冊（舊方法）
    public boolean registerUser(String userId, String password, boolean isAdmin) {
        if (users.containsKey(userId)) {
            return false;
        }
        users.put(userId, new UserAccount(userId, password, isAdmin));
        return true;
    }

    // 檢查是否已登入
    public boolean isLoggedIn() {
        return currentUserId != null;
    }

    // 獲取當前用戶 ID
    public String getCurrentUserId() {
        return currentUserId;
    }

    // 檢查當前用戶是否為管理員
    public boolean isCurrentUserAdmin() {
        return isCurrentUserAdmin;
    }

    // 登出
    public void logout() {
        currentUserId = null;
        isCurrentUserAdmin = false;
    }

    // 獲取用戶信息
    public UserAccount getUserInfo(String userId) {
        return users.get(userId);
    }

    // 更新用戶密碼
    public boolean updatePassword(String userId, String oldPassword, String newPassword) {
        UserAccount account = users.get(userId);
        if (account != null && account.password.equals(oldPassword)) {
            account.password = newPassword;
            return true;
        }
        return false;
    }

    // 更新用戶信息
    public boolean updateUserInfo(String userId, String email, String phone) {
        UserAccount account = users.get(userId);
        if (account != null) {
            account.email = email;
            account.phone = phone;
            return true;
        }
        return false;
    }

    // 獲取所有用戶（僅管理員可用）
    public Map<String, UserAccount> getAllUsers() {
        if (isCurrentUserAdmin) {
            return new HashMap<>(users);
        }
        return new HashMap<>();
    }

    // 刪除用戶（僅管理員可用）
    public boolean deleteUser(String userId) {
        if (isCurrentUserAdmin && !userId.equals(currentUserId)) {
            return users.remove(userId) != null;
        }
        return false;
    }

    // 重置用戶密碼（僅管理員可用）
    public boolean resetUserPassword(String userId, String newPassword) {
        if (isCurrentUserAdmin) {
            UserAccount account = users.get(userId);
            if (account != null) {
                account.password = newPassword;
                return true;
            }
        }
        return false;
    }
}
