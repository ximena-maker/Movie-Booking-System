package org.example.App.services;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

public class BookingService {
    private List<Movie> movies = new ArrayList<>();
    private List<Booking> bookings = new ArrayList<>();
    private Map<String, Integer> movieRemaining = new HashMap<>();

    // ✅ 定義 Movie 內部類，所有字段 PUBLIC
    public static class Movie {
        public String title;
        public String director;
        public String description;
        public double rating;
        public int duration;

        public Movie(String title, String director, String description, double rating, int duration) {
            this.title = title;
            this.director = director;
            this.description = description;
            this.rating = rating;
            this.duration = duration;
        }
    }

    // ✅ 定義 Booking 內部類
    public static class Booking {
        public String bookingId;
        public String userId;
        public String movieTitle;
        public String cinema;
        public LocalDate bookingDate;
        public LocalTime bookingTime;
        public List<String> seats;
        public int totalPrice;
        public String ticketCode;
        public String status;

        public Booking(String bookingId, String userId, String movieTitle, String cinema,
                       LocalDate bookingDate, LocalTime bookingTime, List<String> seats, int totalPrice) {
            this.bookingId = bookingId;
            this.userId = userId;
            this.movieTitle = movieTitle;
            this.cinema = cinema;
            this.bookingDate = bookingDate;
            this.bookingTime = bookingTime;
            this.seats = new ArrayList<>(seats);
            this.totalPrice = totalPrice;
            this.ticketCode = generateTicketCode();
            this.status = "已確認";
        }

        private String generateTicketCode() {
            return "TK" + System.currentTimeMillis() % 1000000;
        }
    }

    public BookingService() {
        initializeMovies();
    }

    private void initializeMovies() {
        movies.add(new Movie(
                "阿凡達：火與燼",
                "詹姆斯·卡梅隆",
                "潘多拉星球的冒險繼續。傑克和納美人族必須聯合對抗新的威脅。",
                9.2,
                192
        ));
        movies.add(new Movie(
                "黑豹：瓦坎達萬歲",
                "瑞恩·庫格勒",
                "瓦坎達的英雄們為王國而戰，守護他們的家園和人民。",
                8.8,
                161
        ));
        movies.add(new Movie(
                "奧本海默",
                "克里斯托弗·諾蘭",
                "美國物理學家J·羅伯特·奧本海默和曼哈頓計畫的故事。",
                8.5,
                180
        ));
        movies.add(new Movie(
                "劇場版 咒術迴戰 0",
                "朴性厚",
                "在詛咒肆虐的世界裡，少年們踏上救贖之路。",
                8.9,
                150
        ));
        movies.add(new Movie(
                "鬼滅之刃 遊郭篇",
                "外崎春雄",
                "炭治郎進入燈紅酒綠的遊郭，對抗上弦妓夫太郎。",
                9.0,
                144
        ));

        for (Movie movie : movies) {
            movieRemaining.put(movie.title, 150);
        }
    }

    // ✅ 獲取所有電影
    public List<Movie> getMovies() {
        return new ArrayList<>(movies);
    }

    // ✅ 根據標題獲取電影
    public Movie getMovieByTitle(String title) {
        for (Movie movie : movies) {
            if (movie.title.equals(title)) {
                return movie;
            }
        }
        return null;
    }

    // ✅ 創建訂單
    public Booking createBooking(String userId, String movieTitle, String cinema,
                                 LocalDate date, LocalTime time, List<String> seats, int totalPrice) {
        String bookingId = "BK" + System.currentTimeMillis() % 1000000;
        Booking booking = new Booking(bookingId, userId, movieTitle, cinema, date, time, seats, totalPrice);
        bookings.add(booking);
        return booking;
    }

    // ✅ 確認付款
    public void confirmPayment(Booking booking) {
        booking.status = "已付款";
    }

    // ✅ 更新剩餘座位
    public void updateRemaining(String movieTitle, int quantity) {
        int remaining = movieRemaining.getOrDefault(movieTitle, 0);
        movieRemaining.put(movieTitle, Math.max(0, remaining - quantity));
    }

    // ✅ 獲取用戶訂單
    public List<Booking> getUserBookings(String userId) {
        List<Booking> userBookings = new ArrayList<>();
        for (Booking booking : bookings) {
            if (booking.userId.equals(userId)) {
                userBookings.add(booking);
            }
        }
        return userBookings;
    }

    // ✅ 退票
    public boolean refundBooking(String bookingId) {
        for (Booking booking : bookings) {
            if (booking.bookingId.equals(bookingId)) {
                booking.status = "已退票";
                return true;
            }
        }
        return false;
    }

    // ✅ 獲取所有訂單
    public List<Booking> getAllBookings() {
        return new ArrayList<>(bookings);
    }

    // ✅ 獲取剩餘座位數
    public int getRemaining(String movieTitle) {
        return movieRemaining.getOrDefault(movieTitle, 0);
    }
}
