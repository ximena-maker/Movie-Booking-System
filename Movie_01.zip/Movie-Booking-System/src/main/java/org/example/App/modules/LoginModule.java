package org.example.App.modules;

import javafx.geometry.Insets;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import org.example.App.services.UserService;

public class LoginModule {
    private UserService userService;
    private Label userLabel;

    public LoginModule(UserService userService, Label userLabel) {
        this.userService = userService;
        this.userLabel = userLabel;
    }

    public void show() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("登入 / 註冊");

        TabPane tabs = new TabPane();
        tabs.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);
        tabs.setStyle("-fx-background-color: #0b1220;");

        TextField loginEmail = new TextField();
        loginEmail.setPromptText("Email");
        loginEmail.getStyleClass().add("light-input");

        PasswordField loginPw = new PasswordField();
        loginPw.setPromptText("密碼");
        loginPw.getStyleClass().add("light-input");

        Button forgotBtn = new Button("忘記密碼？");
        forgotBtn.getStyleClass().add("link-button");
        forgotBtn.setOnAction(e -> showForgotPasswordDialog());

        VBox loginBox = new VBox(10, new Label("登入"), loginEmail, loginPw, forgotBtn);
        loginBox.setPadding(new Insets(12));
        Tab loginTab = new Tab("登入", loginBox);
        loginTab.setStyle("-fx-text-fill: white;");

        TextField regName = new TextField();
        regName.setPromptText("暱稱");
        regName.getStyleClass().add("light-input");

        TextField regEmail = new TextField();
        regEmail.setPromptText("Email");
        regEmail.getStyleClass().add("light-input");

        PasswordField regPw = new PasswordField();
        regPw.setPromptText("密碼");
        regPw.getStyleClass().add("light-input");

        PasswordField regPwConfirm = new PasswordField();
        regPwConfirm.setPromptText("確認密碼");
        regPwConfirm.getStyleClass().add("light-input");

        VBox regBox = new VBox(10, new Label("註冊"), regName, regEmail, regPw, regPwConfirm);
        regBox.setPadding(new Insets(12));
        Tab regTab = new Tab("註冊", regBox);
        regTab.setStyle("-fx-text-fill: white;");

        tabs.getTabs().addAll(loginTab, regTab);

        dialog.getDialogPane().setContent(tabs);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dialog.getDialogPane().setStyle("-fx-background-color: #0b1220;");

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK) {
                if (tabs.getSelectionModel().getSelectedItem() == loginTab) {
                    String email = loginEmail.getText().trim();
                    String pw = loginPw.getText().trim();
                    if (!email.isBlank() && !pw.isBlank()) {
                        userService.login(email, pw);
                        userLabel.setText("已登入: " + email);
                    } else {
                        showAlert("請輸入 Email 與密碼");
                    }
                } else {
                    String name = regName.getText().trim();
                    String email = regEmail.getText().trim();
                    String pw = regPw.getText().trim();
                    String pwConfirm = regPwConfirm.getText().trim();
                    if (name.isBlank() || email.isBlank() || pw.isBlank()) {
                        showAlert("請填寫完整資料");
                    } else if (!pw.equals(pwConfirm)) {
                        showAlert("密碼不一致");
                    } else {
                        userService.register(name, email, pw);
                        userLabel.setText("已登入: " + name);
                    }
                }
            }
            return btn;
        });

        dialog.showAndWait();
    }

    private void showForgotPasswordDialog() {
        Dialog<ButtonType> dialog = new Dialog<>();
        dialog.setTitle("忘記密碼");

        TextField resetEmail = new TextField();
        resetEmail.setPromptText("輸入您的 Email");
        resetEmail.getStyleClass().add("light-input");

        VBox box = new VBox(10, new Label("我們將發送重設連結到您的信箱"), resetEmail);
        box.setPadding(new Insets(12));

        dialog.getDialogPane().setContent(box);
        dialog.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        dialog.getDialogPane().setStyle("-fx-background-color: #0b1220;");

        dialog.setResultConverter(btn -> {
            if (btn == ButtonType.OK && !resetEmail.getText().isBlank()) {
                userService.resetPassword(resetEmail.getText());
                showAlert("重設連結已發送到 " + resetEmail.getText());
            }
            return btn;
        });

        dialog.showAndWait();
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg);
        alert.getDialogPane().setStyle("-fx-background-color: #0b1220;");
        alert.showAndWait();
    }
}
