package org.example.App;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import org.example.App.modules.*;
import org.example.App.services.*;

public class MainApp extends Application {
    private UserService userService;
    private BookingService bookingService;
    private PriceService priceService;
    private BorderPane root;
    private StackPane contentArea;
    private Label userStatusLabel;
    private boolean isLoggedIn = false;
    private String currentUserId;
    private boolean isAdmin = false;

    @Override
    public void start(Stage stage) {
        // 初始化服務
        userService = new UserService();
        bookingService = new BookingService();
        priceService = new PriceService();

        // 初始化測試用戶和管理員
        initializeTestUsers();

        // 設置主容器
        root = new BorderPane();
        root.setStyle("-fx-background-color: #0b1220;");

        // 設置頂部導航欄
        root.setTop(createTopBar());

        // 設置內容區域
        contentArea = new StackPane();
        contentArea.setStyle("-fx-background-color: #0b1220;");
        root.setCenter(contentArea);

        // 初始顯示登入頁面
        showLoginPage();

        Scene scene = new Scene(root, 1400, 800);
        stage.setTitle("🎬 電影訂票系統");
        stage.setScene(scene);
        stage.show();
    }

    private VBox createTopBar() {
        VBox topBar = new VBox();
        topBar.setStyle("-fx-background-color: #1a2637; -fx-padding: 15;");
        topBar.setPrefHeight(80);

        HBox navBox = new HBox(20);
        navBox.setPadding(new Insets(10));
        navBox.setStyle("-fx-alignment: center-left;");

        // Logo
        Label logo = new Label("🎬 CineHub");
        logo.setStyle("-fx-font-size: 24; -fx-font-weight: bold; -fx-text-fill: #32b8c6;");

        // 導航按鈕
        Button movieBtn = createNavButton("🎥 電影推薦", e -> showMovieRecommendation());
        Button priceBtn = createNavButton("💰 比價", e -> showPricing());
        Button bookingBtn = createNavButton("🎫 訂票", e -> {
            if (isLoggedIn && !isAdmin) showBooking();
            else if (!isLoggedIn) showAlert("❌ 請先登入才能訂票");
            else showAlert("❌ 管理員無法訂票");
        });
        Button myOrderBtn = createNavButton("📋 我的訂單", e -> {
            if (isLoggedIn && !isAdmin) showMyOrders();
            else if (!isLoggedIn) showAlert("❌ 請先登入");
        });
        Button refundBtn = createNavButton("↩️ 退票", e -> {
            if (isLoggedIn && !isAdmin) showRefund();
            else if (!isLoggedIn) showAlert("❌ 請先登入");
        });
        Button adminBtn = createNavButton("⚙️ 管理系統", e -> {
            if (isAdmin) showAdmin();
            else showAlert("❌ 僅管理員可使用");
        });

        HBox navButtons = new HBox(10);
        navButtons.setStyle("-fx-alignment: center-left;");

        if (!isLoggedIn) {
            navButtons.getChildren().addAll(movieBtn, priceBtn);
        } else if (isAdmin) {
            navButtons.getChildren().addAll(adminBtn);
        } else {
            navButtons.getChildren().addAll(movieBtn, priceBtn, bookingBtn, myOrderBtn, refundBtn);
        }

        Spacer spacer = new Spacer();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        userStatusLabel = new Label();
        updateUserStatus();
        userStatusLabel.setStyle("-fx-text-fill: #32b8c6; -fx-font-size: 12;");

        // ✅ 修正：遊客和已登陸用戶都能點擊登出/登入
        Button loginLogoutBtn = createNavButton(isLoggedIn ? "🚪 登出" : "🔑 登入", e -> {
            if (isLoggedIn) {
                logout();
            } else {
                showLoginPage();
            }
        });

        navBox.getChildren().addAll(logo, new Separator(javafx.geometry.Orientation.VERTICAL),
                navButtons, spacer, userStatusLabel, loginLogoutBtn);

        topBar.getChildren().add(navBox);
        return topBar;
    }

    private Button createNavButton(String text, javafx.event.EventHandler<javafx.event.ActionEvent> action) {
        Button btn = new Button(text);
        btn.setStyle("-fx-font-size: 14; -fx-padding: 8 16; -fx-background-color: #32b8c6; " +
                "-fx-text-fill: white; -fx-border-radius: 5; -fx-cursor: hand;");
        btn.setOnAction(action);
        btn.setOnMouseEntered(e -> btn.setStyle("-fx-font-size: 14; -fx-padding: 8 16; -fx-background-color: #2a9aa8; " +
                "-fx-text-fill: white; -fx-border-radius: 5; -fx-cursor: hand;"));
        btn.setOnMouseExited(e -> btn.setStyle("-fx-font-size: 14; -fx-padding: 8 16; -fx-background-color: #32b8c6; " +
                "-fx-text-fill: white; -fx-border-radius: 5; -fx-cursor: hand;"));
        return btn;
    }

    private void showLoginPage() {
        VBox loginBox = new VBox(20);
        loginBox.setStyle("-fx-alignment: center; -fx-padding: 50; -fx-background-color: #0b1220;");

        Label title = new Label("🎬 歡迎來到 CineHub");
        title.setStyle("-fx-font-size: 32; -fx-font-weight: bold; -fx-text-fill: #32b8c6;");

        VBox formBox = new VBox(15);
        formBox.setPadding(new Insets(30));
        formBox.setStyle("-fx-border-color: rgba(50,184,198,0.3); -fx-border-radius: 10; " +
                "-fx-background-color: rgba(26,38,55,0.8); -fx-max-width: 400;");

        Label loginLabel = new Label("用戶登入");
        loginLabel.setStyle("-fx-font-size: 20; -fx-text-fill: white;");

        TextField usernameField = new TextField();
        usernameField.setPromptText("用戶名");
        usernameField.setStyle("-fx-padding: 10; -fx-font-size: 14; -fx-border-radius: 5;");

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("密碼");
        passwordField.setStyle("-fx-padding: 10; -fx-font-size: 14; -fx-border-radius: 5;");

        Button loginBtn = new Button("登入");
        loginBtn.setStyle("-fx-padding: 12 40; -fx-font-size: 14; -fx-background-color: #32b8c6; " +
                "-fx-text-fill: white; -fx-border-radius: 5;");

        Button guestBtn = new Button("以遊客身份瀏覽");
        guestBtn.setStyle("-fx-padding: 12 40; -fx-font-size: 14; -fx-background-color: #5e5240; " +
                "-fx-text-fill: white; -fx-border-radius: 5;");

        Label testLabel = new Label("測試帳號：\n管理員: Admin / 1234\n顧客1: A01 / 1234\n顧客2: A02 / 1234");
        testLabel.setStyle("-fx-text-fill: rgba(255,255,255,0.6); -fx-font-size: 12;");

        loginBtn.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();
            if (username.isEmpty() || password.isEmpty()) {
                showAlert("❌ 請輸入用戶名和密碼");
                return;
            }
            if (userService.authenticate(username, password)) {
                isLoggedIn = true;
                currentUserId = username;
                isAdmin = "Admin".equals(username);
                root.setTop(createTopBar());
                updateUserStatus();
                if (isAdmin) {
                    showAdmin();
                } else {
                    showMovieRecommendation();
                }
            } else {
                showAlert("❌ 用戶名或密碼錯誤");
            }
        });

        guestBtn.setOnAction(e -> {
            isLoggedIn = false;
            currentUserId = null;
            isAdmin = false;
            root.setTop(createTopBar());
            showMovieRecommendation();
        });

        formBox.getChildren().addAll(loginLabel, usernameField, passwordField, loginBtn, guestBtn, testLabel);
        loginBox.getChildren().addAll(title, formBox);

        contentArea.getChildren().clear();
        contentArea.getChildren().add(loginBox);
    }

    private void showMovieRecommendation() {
        VBox container = new VBox(20);
        container.setPadding(new Insets(30));
        container.setStyle("-fx-background-color: #0b1220;");

        Label title = new Label("🎥 電影推薦");
        title.setStyle("-fx-font-size: 28; -fx-text-fill: #32b8c6; -fx-font-weight: bold;");

        VBox moviesBox = new VBox(15);
        moviesBox.setPadding(new Insets(20));
        moviesBox.setStyle("-fx-border-color: rgba(50,184,198,0.2); -fx-border-radius: 10; " +
                "-fx-background-color: rgba(26,38,55,0.5);");

        for (BookingService.Movie movie : bookingService.getMovies()) {
            HBox movieCard = createMovieCard(movie);
            moviesBox.getChildren().add(movieCard);
        }

        ScrollPane scrollPane = new ScrollPane(moviesBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: #0b1220;");

        container.getChildren().addAll(title, scrollPane);
        VBox.setVgrow(scrollPane, Priority.ALWAYS);

        contentArea.getChildren().clear();
        contentArea.getChildren().add(container);
    }

    private HBox createMovieCard(BookingService.Movie movie) {
        HBox card = new HBox(20);
        card.setPadding(new Insets(15));
        card.setStyle("-fx-border-color: rgba(50,184,198,0.3); -fx-border-radius: 8; " +
                "-fx-background-color: rgba(31,33,33,0.8); -fx-spacing: 15;");

        VBox infoBox = new VBox(8);
        Label movieTitle = new Label(movie.title);
        movieTitle.setStyle("-fx-font-size: 18; -fx-font-weight: bold; -fx-text-fill: #32b8c6;");

        Label director = new Label("導演: " + movie.director);
        director.setStyle("-fx-text-fill: rgba(255,255,255,0.8);");

        Label rating = new Label("⭐ 評分: " + movie.rating + "/10");
        rating.setStyle("-fx-text-fill: #ffd700;");

        Label duration = new Label("⏱️ 片長: " + movie.duration + " 分鐘");
        duration.setStyle("-fx-text-fill: rgba(255,255,255,0.8);");

        Label description = new Label(movie.description);
        description.setStyle("-fx-text-fill: rgba(255,255,255,0.7); -fx-wrap-text: true;");
        description.setWrapText(true);

        infoBox.getChildren().addAll(movieTitle, director, rating, duration, description);
        card.getChildren().add(infoBox);
        HBox.setHgrow(infoBox, Priority.ALWAYS);

        return card;
    }

    private void showPricing() {
        VBox container = new VBox(20);
        container.setPadding(new Insets(30));
        container.setStyle("-fx-background-color: #0b1220;");

        Label title = new Label("💰 電影比價");
        title.setStyle("-fx-font-size: 28; -fx-text-fill: #32b8c6; -fx-font-weight: bold;");

        HBox filterBox = new HBox(15);
        filterBox.setPadding(new Insets(15));
        filterBox.setStyle("-fx-border-color: rgba(50,184,198,0.2); -fx-border-radius: 10; " +
                "-fx-background-color: rgba(26,38,55,0.5);");

        Label movieLabel = new Label("選擇電影:");
        movieLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14;");

        ComboBox<String> movieBox = new ComboBox<>();
        for (BookingService.Movie m : bookingService.getMovies()) {
            movieBox.getItems().add(m.title);
        }
        movieBox.setValue("阿凡達：火與燼");
        movieBox.setStyle("-fx-font-size: 14;");

        Label cinemaLabel = new Label("選擇影城:");
        cinemaLabel.setStyle("-fx-text-fill: white; -fx-font-size: 14;");

        ComboBox<String> cinemaBox = new ComboBox<>();
        cinemaBox.getItems().addAll("威秀電影城", "國賓大戲院", "美麗華影城", "信義威秀");
        cinemaBox.setValue("威秀電影城");
        cinemaBox.setStyle("-fx-font-size: 14;");

        filterBox.getChildren().addAll(movieLabel, movieBox, cinemaLabel, cinemaBox);

        VBox priceBox = new VBox(15);
        priceBox.setPadding(new Insets(20));
        priceBox.setStyle("-fx-border-color: rgba(50,184,198,0.2); -fx-border-radius: 10; " +
                "-fx-background-color: rgba(26,38,55,0.5);");

        javafx.event.EventHandler<javafx.event.ActionEvent> updatePrices = e -> {
            String selectedMovie = movieBox.getValue();
            String selectedCinema = cinemaBox.getValue();
            priceBox.getChildren().clear();

            String[] ticketTypes = {"全票", "學生票", "敬老票", "孩童票"};
            int[] prices = {300, 250, 200, 150};

            Label cinemaInfo = new Label("🎬 " + selectedCinema);
            cinemaInfo.setStyle("-fx-font-size: 16; -fx-font-weight: bold; -fx-text-fill: #32b8c6;");
            priceBox.getChildren().add(cinemaInfo);

            HBox pricesRow = new HBox(15);
            pricesRow.setPadding(new Insets(15));

            for (int i = 0; i < ticketTypes.length; i++) {
                VBox ticketBox = new VBox(8);
                ticketBox.setPadding(new Insets(12));
                ticketBox.setStyle("-fx-border-color: rgba(50,184,198,0.3); -fx-border-radius: 8; " +
                        "-fx-background-color: rgba(31,33,33,0.8); -fx-alignment: center;");

                Label typeLabel = new Label(ticketTypes[i]);
                typeLabel.setStyle("-fx-text-fill: white; -fx-font-size: 13; -fx-font-weight: bold;");

                Label priceLabel = new Label("NT$ " + prices[i]);
                priceLabel.setStyle("-fx-text-fill: #32b8c6; -fx-font-size: 18; -fx-font-weight: bold;");

                ticketBox.getChildren().addAll(typeLabel, priceLabel);
                pricesRow.getChildren().add(ticketBox);
            }

            priceBox.getChildren().add(pricesRow);
        };

        movieBox.setOnAction(updatePrices);
        cinemaBox.setOnAction(updatePrices);
        updatePrices.handle(null);

        ScrollPane scrollPane = new ScrollPane(priceBox);
        scrollPane.setFitToWidth(true);
        scrollPane.setStyle("-fx-background-color: #0b1220;");

        container.getChildren().addAll(title, filterBox, scrollPane);
        VBox.setVgrow(scrollPane, Priority.ALWAYS);

        contentArea.getChildren().clear();
        contentArea.getChildren().add(container);
    }

    private void showBooking() {
        BookingModule bookingModule = new BookingModule(userService, bookingService, priceService);
        Node bookingUI = bookingModule.build();

        contentArea.getChildren().clear();
        contentArea.getChildren().add(bookingUI);
    }

    private void showMyOrders() {
        OrderModule orderModule = new OrderModule(bookingService, userService);
        Node orderUI = orderModule.build();

        contentArea.getChildren().clear();
        contentArea.getChildren().add(orderUI);
    }

    private void showRefund() {
        RefundModule refundModule = new RefundModule(bookingService, userService);
        Node refundUI = refundModule.build();

        contentArea.getChildren().clear();
        contentArea.getChildren().add(refundUI);
    }

    private void showAdmin() {
        AdminModule adminModule = new AdminModule(userService, bookingService, priceService);
        ScrollPane adminUI = new ScrollPane(adminModule.build());
        adminUI.setFitToWidth(true);
        adminUI.setStyle("-fx-background-color: #0b1220;");

        contentArea.getChildren().clear();
        contentArea.getChildren().add(adminUI);
    }

    private void logout() {
        isLoggedIn = false;
        isAdmin = false;
        currentUserId = null;
        root.setTop(createTopBar());
        showLoginPage();
    }

    private void updateUserStatus() {
        if (isLoggedIn) {
            userStatusLabel.setText(isAdmin ? "👤 管理員: " + currentUserId : "👤 用戶: " + currentUserId);
        } else {
            userStatusLabel.setText("👤 遊客身份");
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION, msg);
        alert.setTitle("提示");
        alert.getDialogPane().setStyle("-fx-background-color: #0b1220; -fx-text-fill: white;");
        alert.showAndWait();
    }

    private void initializeTestUsers() {
        // 添加測試用戶（在實際應用中應該從數據庫讀取）
        userService.registerUser("Admin", "1234", true);
        userService.registerUser("A01", "1234", false);
        userService.registerUser("A02", "1234", false);
    }

    public static void main(String[] args) {
        launch(args);
    }
}

class Spacer extends Region {
    public Spacer() {
        setPrefHeight(1);
    }
}
