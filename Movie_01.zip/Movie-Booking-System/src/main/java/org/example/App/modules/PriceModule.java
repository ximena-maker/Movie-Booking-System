package org.example.App.modules;

import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.VBox;
import org.example.App.services.PriceService;

import java.util.ArrayList;
import java.util.List;

public class PriceModule {
    private PriceService priceService;

    public PriceModule(PriceService priceService) {
        this.priceService = priceService;
    }

    public static class PriceDisplay {
        public String cinema;
        public String format;
        public String ticketType;
        public int price;
        public String source;

        public PriceDisplay(String cinema, String format, String ticketType, int price, String source) {
            this.cinema = cinema;
            this.format = format;
            this.ticketType = ticketType;
            this.price = price;
            this.source = source;
        }

        public String getCinema() { return cinema; }
        public String getFormat() { return format; }
        public String getTicketType() { return ticketType; }
        public int getPrice() { return price; }
        public String getSource() { return source; }
    }

    public Node build() {
        VBox root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #0b1220;");

        Label title = new Label("比價");
        title.getStyleClass().add("h2");

        ComboBox<String> formatBox = new ComboBox<>();
        formatBox.getItems().addAll("2D", "3D", "IMAX");
        formatBox.setValue("2D");

        ComboBox<String> ticketBox = new ComboBox<>();
        ticketBox.getItems().addAll("全票", "學生票", "敬老票");
        ticketBox.setValue("全票");

        Label lowestPrice = new Label("最低價: —");
        lowestPrice.setStyle("-fx-text-fill: #32c0a6; -fx-font-weight: bold; -fx-font-size: 16;");

        Button compareBtn = new Button("開始比價");
        compareBtn.getStyleClass().add("primary");

        HBox filterBox = new HBox(15);
        filterBox.setPadding(new Insets(10));
        filterBox.setStyle("-fx-border-color: rgba(255,255,255,0.08); -fx-border-radius: 8;");
        filterBox.getChildren().addAll(
                new Label("格式:"), formatBox,
                new Label("票種:"), ticketBox,
                lowestPrice,
                compareBtn
        );

        TableView<PriceDisplay> table = new TableView<>();
        table.getStyleClass().add("table");

        TableColumn<PriceDisplay, String> cinemaCol = new TableColumn<>("影城");
        cinemaCol.setCellValueFactory(new PropertyValueFactory<>("cinema"));
        cinemaCol.setPrefWidth(150);

        TableColumn<PriceDisplay, String> formatCol = new TableColumn<>("版本");
        formatCol.setCellValueFactory(new PropertyValueFactory<>("format"));
        formatCol.setPrefWidth(100);

        TableColumn<PriceDisplay, String> ticketCol = new TableColumn<>("票種");
        ticketCol.setCellValueFactory(new PropertyValueFactory<>("ticketType"));
        ticketCol.setPrefWidth(100);

        TableColumn<PriceDisplay, Integer> priceCol = new TableColumn<>("價格");
        priceCol.setCellValueFactory(new PropertyValueFactory<>("price"));
        priceCol.setPrefWidth(100);
        priceCol.setCellFactory(col -> new TableCell<PriceDisplay, Integer>() {
            @Override
            protected void updateItem(Integer item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || item == null) {
                    setText("—");
                } else {
                    setText("NT$ " + item);
                }
            }
        });

        TableColumn<PriceDisplay, String> sourceCol = new TableColumn<>("來源");
        sourceCol.setCellValueFactory(new PropertyValueFactory<>("source"));
        sourceCol.setPrefWidth(150);

        table.getColumns().addAll(cinemaCol, formatCol, ticketCol, priceCol, sourceCol);

        compareBtn.setOnAction(e -> {
            String format = formatBox.getValue();
            String ticketType = ticketBox.getValue();

            String formatKey = "2D".equals(format) ? "2D" : ("3D".equals(format) ? "3D" : "IMAX");
            String ticketKey = "全票".equals(ticketType) ? "ADULT" : ("學生票".equals(ticketType) ? "STUDENT" : "SENIOR");

            List<PriceService.PriceQuote> quotes = priceService.compare(formatKey, ticketKey);
            List<PriceDisplay> displayList = new ArrayList<>();

            for (PriceService.PriceQuote q : quotes) {
                displayList.add(new PriceDisplay(q.cinema, q.format, q.ticketType, q.price, q.source));
            }

            table.getItems().setAll(displayList);

            int lowest = priceService.getLowestPrice(formatKey, ticketKey);
            lowestPrice.setText("最低價: NT$ " + lowest);
        });

        VBox filterSection = new VBox(10, filterBox, table);
        VBox.setVgrow(table, Priority.ALWAYS);

        root.getChildren().addAll(title, filterSection);
        return root;
    }
}
